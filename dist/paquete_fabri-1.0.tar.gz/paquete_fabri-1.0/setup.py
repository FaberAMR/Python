from setuptools import setup       

setup(
    name="paquete_fabri", 
    version="1.0",
    description="Estamos haciendo un paquete",
    author="Fabricio Guiffrey",
    author_email="amrcdelu@gmail.com",

    packages= ["paquete_fabri"]
)